import os, json, hashlib

root = "bundle_root"
entries = []

for dp, _, fns in os.walk(root):
    for fn in sorted(fns):
        p = os.path.join(dp, fn)
        rel = os.path.relpath(p, root).replace("\\","/")
        with open(p,"rb") as f:
            data = f.read()
        sha  = hashlib.sha256(data).hexdigest()
        size = len(data)
        entries.append({"path": rel, "sha256": sha, "size_bytes": size})

entries.sort(key=lambda e: e["path"])
manifest = {"version": 1, "root": root, "entries": entries}
s = json.dumps(manifest, ensure_ascii=True, sort_keys=True, separators=(",",":")) + "\n"

os.makedirs("provenance", exist_ok=True)
with open(os.path.join("provenance","manifest.json"),"wb") as f:
    f.write(s.encode("utf-8"))