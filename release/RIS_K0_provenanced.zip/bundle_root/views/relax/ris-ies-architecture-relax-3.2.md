RIS/IES Architecture v3.2 – RELAX (non-normative)

Source: INTERNAL
Date: 2025-11-12
Status: DRAFT-NORMATIVE (not part of K0)
Compatibility: RIS_CoreCorpus_3.0 (immutable reference)
Primary language: English
Encoding: UTF-8 (LF-only)

Purpose and Scope

RELAX v3.2 defines a dual determinism model:

Semantic determinism: identical AST content yields identical semantic_hash_ns independent of formatting or I/O drift.
Audit determinism: byte-stable audit artifacts derived deterministically from the semantic layer.

The goal is to keep the cryptographic spine while removing pathological byte fragility.

Model Overview

2.1 Semantic determinism

AST typing (allowed types):
List, Symbol, String, Int, Float, Bool, Timestamp, Uuid, Sha512, HexFloat.

Normalization rules:
Unicode NFKD; stable key order (lex); stable array order unless typed as Set; numbers normalized to binary64; NaN/Inf forbidden; negative zero normalized to +0; strings minimally escaped.

Semantic canonical form (SCF): stable serialization of the AST.

Hash definitions:
semantic_hash_raw = SHA-512(SCF_bytes)
semantic_hash_ns = SHA-512("RIS3.2/SEMANTIC" || SCF_bytes)

Merkle tree:
H_i = SHA-512(SCF(module_i))
root = SHA-512(concat_lex(H_i))

2.2 Audit determinism

Audit channel uses canonical JSON: newline \n; ASCII-safe; hex-float rendering or typed float object; exactly one final newline.
byte_hash computed from deterministic bundle scope.

Tolerated Drift Windows

These differences do not change semantic determinism:
\r\n vs \n; Unicode NFC vs NFKD; float renderings that round-trip to the same binary64.

Audit artifacts remain stable; CI records drift metrics.

Policy Management

Authoritative source: policy.edn.
Canonical export: policy.json.

Subtree hash:
policy_subhash = SHA-256(SCF(subtree))

Detached Ed25519 signature over canonical policy.json.

Namespaces:
ris.core.* (core), ris.sys.* (pipeline), x_* (extensions, never fail audit).

Seeds and RNG

HMAC-based deterministic RNG:
seed_anchor = semantic_hash_ns || ":" || corpus_id || ":" || arch_major_minor

seed_i = first_64_bits(HMAC-SHA256(key = seed_master, msg = seed_anchor || ":" || seed_domain || ":" || window_uuid || ":" || fold_idx))

Domains: cv, bootstrap, permtest, etc.

Determinism check:
rng_stream_hash_1e5 = SHA-256(first 1e5 uniforms)

Numbers and Floats

6.1 Strict profile (audit layer)

Allowed hex-float pattern:
^0x[0-9a-f]+(.[0-9a-f]+)?p[+-][0-9]+$

NaN/Inf forbidden.
Negative zero forbidden.

6.2 Relaxed profile (semantic/analysis)

Typed float object:
{ "alpha_hat": { "hex": "0x1.fae147ae147aep-1", "num": 0.98 } }

QC Semantics (RIS-QC-2.0)

Bitmask preserved; classes and severity added.

Reserved bits:
22 FAIL_VARIANCE_PARITY
23 FAIL_TOLERANCE_DRIFT
39 WARN_PENDING_SOURCE
40 SECRET_DETECTED
41 ENV_DIVERGENCE_TOL

Example QC entry:
{ "qc": { "mask": 4194304, "flags": ["FAIL_VARIANCE_PARITY"], "class": "FAIL_ANALYSIS", "severity": 2 } }

HRF Gate (fMRI only)

Modes: canonical, dataset, pending_source.

Example:
{ "fmri": { "hrf": { "mode": "pending_source", "shift_sec": { "hex": "0x1p+2", "num": 4.0 } } } }

Packaging and Hashing

Two allowed modes:

9.1 PAX TAR
ASCII headers; mtime=0; uid=gid=0; entry order: byte-lex with "/";
byte_hash = SHA-512(uncompressed_tar_bytes)

9.2 File-hash concatenation
H_file = SHA-512(audit_file_bytes)
byte_hash = SHA-512(concat_lex(H_file_i))

Record packaging mode in provenance.

Manifest Rules

Exclude: MANIFEST.stage, MANIFEST.txt, ANCHOR.json.
Line format: <sha512_hex>␠␠\n (two spaces).

Example manifest config:
{ "manifest": { "includes": [".json", ".tsv.gz", "*.parquet"], "excludes": ["MANIFEST.stage", "MANIFEST.txt", "ANCHOR.json"], "order": "byte-lex", "line_format": "<sha512_hex> " } }

Environment Determinism

Environment fingerprint fields:
rounding: ties-to-even
fma: requested=off, effective=on
denormals: preserve
blas: type=mkl, version=2025.0
numeric_fingerprint: rel_tol=1e-12, tests_pass=true

Example:
{ "rounding": "ties-to-even", "fma": { "requested": "off", "effective": "on" }, "denormals": "preserve", "blas": { "type": "mkl", "version": "2025.0" }, "numeric_fingerprint": { "rel_tol": 1e-12, "tests_pass": true } }

Provenance (View-level)

{ "provenance": { "semantic_hash_ns": "<sha512_hex>", "merkle_root": "<sha512_hex>", "byte_hash": "<sha512_hex>", "packaging_mode": "PAX_TAR|FILE_HASH_CONCAT", "policy_subhashes": {}, "dep_graph_hash": "<sha512_hex>", "source_date_epoch": 1762905600 } }

[COMPLIANCE]
Encoding: utf-8
Newline: \n
Tabs: 0
Trailing_spaces: 0
Final_lf: 1
Placeholders: none
[/COMPLIANCE]